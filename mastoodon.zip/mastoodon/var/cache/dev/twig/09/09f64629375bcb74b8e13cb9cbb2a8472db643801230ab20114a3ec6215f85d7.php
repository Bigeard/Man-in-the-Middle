<?php

/* security/sign_up.html.twig */
class __TwigTemplate_916732fc9d7439935adcb9598f806ebc180380d3d847342b0710c5c86af6beed extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "security/sign_up.html.twig", 1);
        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "security/sign_up.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "security/sign_up.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
\t<nav class=\"navbar\">
\t\t<a class=\"logo\" href=\"";
        // line 6
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("LogOutHomePage");
        echo "\"><img src=\"assets/logo.png\"></a>
\t\t<a class=\"main-link\" href=\"";
        // line 7
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("LogInPage");
        echo "\">LOG IN</a>
\t</nav>

\t<section class=\"container\">
\t\t<div class=\"form-container\">
\t\t\t<p>Sign Up</p>

\t\t\t";
        // line 14
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 14, $this->source); })()), 'form_start');
        echo "
\t\t\t";
        // line 15
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 15, $this->source); })()), "surname", []), 'row', ["attr" => ["placeholder" => "First Name"]]);
        echo "
\t\t\t";
        // line 16
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 16, $this->source); })()), "firstname", []), 'row', ["attr" => ["placeholder" => "Surname"]]);
        echo "
\t\t\t";
        // line 17
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 17, $this->source); })()), "email", []), 'row', ["attr" => ["placeholder" => "Email"]]);
        echo "
\t\t\t";
        // line 18
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 18, $this->source); })()), "password", []), 'row', ["attr" => ["placeholder" => "Password"]]);
        echo "
\t\t\t";
        // line 19
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 19, $this->source); })()), "confirmpassword", []), 'row', ["attr" => ["placeholder" => "Password confirmation"]]);
        echo "
\t\t\t<button name=\"button\" type=\"submit\">SIGN UP</button>
\t\t\t";
        // line 21
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 21, $this->source); })()), 'form_end');
        echo "


\t\t\t";
        // line 33
        echo "
\t\t\t<div class=\"form-footer form-footer_sign-up\">
\t\t\t\t<a class=\"sub-link\" href=\"";
        // line 35
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("LogInPage");
        echo "\">LOG IN</a>
\t\t\t</div>
\t\t</div>
\t</section>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "security/sign_up.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  106 => 35,  102 => 33,  96 => 21,  91 => 19,  87 => 18,  83 => 17,  79 => 16,  75 => 15,  71 => 14,  61 => 7,  57 => 6,  53 => 4,  44 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}

\t<nav class=\"navbar\">
\t\t<a class=\"logo\" href=\"{{ path('LogOutHomePage') }}\"><img src=\"assets/logo.png\"></a>
\t\t<a class=\"main-link\" href=\"{{ path('LogInPage') }}\">LOG IN</a>
\t</nav>

\t<section class=\"container\">
\t\t<div class=\"form-container\">
\t\t\t<p>Sign Up</p>

\t\t\t{{ form_start(form) }}
\t\t\t{{ form_row(form.surname, {'attr' :{'placeholder': 'First Name'}}) }}
\t\t\t{{ form_row(form.firstname, {'attr' :{'placeholder': 'Surname'}}) }}
\t\t\t{{ form_row(form.email, {'attr' :{'placeholder': 'Email'}}) }}
\t\t\t{{ form_row(form.password, {'attr' :{'placeholder': 'Password'}}) }}
\t\t\t{{ form_row(form.confirmpassword, {'attr' :{'placeholder': 'Password confirmation'}}) }}
\t\t\t<button name=\"button\" type=\"submit\">SIGN UP</button>
\t\t\t{{ form_end(form) }}


\t\t\t{# <form id=\"new_user\" action=\"\" accept-charset=\"UTF-8\" method=\"post\">
\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t<input placeholder=\"Username\" autofocus=\"autofocus\" class=\"form-control\" type=\"text\" name=\"user[username]\" id=\"user_username\">
\t\t\t\t\t<input placeholder=\"Email\" class=\"form-control\" type=\"email\" value=\"\" name=\"user[email]\" id=\"user_email\">
\t\t\t\t\t<input placeholder=\"Password\" autocomplete=\"off\" class=\"form-control\" type=\"password\" name=\"user[password]\" id=\"user_password\">
\t\t\t\t\t<input placeholder=\"Password Confirmation\" autocomplete=\"off\" class=\"form-control\" type=\"password\" name=\"user[password_confirmation]\">
\t\t\t\t</div>
\t\t\t\t<button name=\"button\" type=\"submit\">SIGN UP</button>
\t\t\t</form> #}

\t\t\t<div class=\"form-footer form-footer_sign-up\">
\t\t\t\t<a class=\"sub-link\" href=\"{{ path('LogInPage') }}\">LOG IN</a>
\t\t\t</div>
\t\t</div>
\t</section>
{% endblock %}


", "security/sign_up.html.twig", "C:\\Users\\samy\\Desktop\\matignon-the-gathering-master\\templates\\security\\sign_up.html.twig");
    }
}
