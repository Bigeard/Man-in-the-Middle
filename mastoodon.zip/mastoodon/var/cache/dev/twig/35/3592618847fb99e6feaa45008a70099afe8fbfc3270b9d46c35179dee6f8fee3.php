<?php

/* security/admin.html.twig */
class __TwigTemplate_d716fc01a870b3e5ee646f1eb650f39e63a881a3b9ac2bb1d1c679252280bf08 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "security/admin.html.twig", 1);
        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "security/admin.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "security/admin.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_body($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "\t<nav class=\"navbar home\">
\t\t<a class=\"logo\" href=\"";
        // line 4
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("LogInHomePage");
        echo "\"><img src=\"assets/logo.png\"></a>
\t\t<!--Check access to Back-Office-->
\t\t";
        // line 6
        if ((twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new Twig_Error_Runtime('Variable "user" does not exist.', 6, $this->source); })()), "getIsAdmin", [], "method") == true)) {
            // line 7
            echo "\t\t\t<a class=\"main-link\" href=\"";
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AdminPage");
            echo "\">BACK-OFFICE</a>
\t\t";
        }
        // line 9
        echo "
\t\t<!--Check number of Ballots in order to summon-->
\t\t";
        // line 11
        if ((twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new Twig_Error_Runtime('Variable "user" does not exist.', 11, $this->source); })()), "getBallotsNumber", [], "method") >= 200)) {
            // line 12
            echo "\t\t\t<a class=\"main-link\" href=\"";
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("SummonPage");
            echo "\">SUMMON</a>
\t\t";
        }
        // line 14
        echo "        <a class=\"main-link\" href=\"";
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("CollectionPage");
        echo "\">COLLECTION</a>
        <div class=\"profil\">
            <p>
                <strong>";
        // line 17
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new Twig_Error_Runtime('Variable "user" does not exist.', 17, $this->source); })()), "getSurname", [], "method"), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new Twig_Error_Runtime('Variable "user" does not exist.', 17, $this->source); })()), "getFirstname", [], "method"), "html", null, true);
        echo "</strong><br>
                ";
        // line 18
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new Twig_Error_Runtime('Variable "user" does not exist.', 18, $this->source); })()), "getRank", [], "method"), "html", null, true);
        echo " | ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new Twig_Error_Runtime('Variable "user" does not exist.', 18, $this->source); })()), "getBallotsNumber", [], "method"), "html", null, true);
        echo " BV
            </p>
        </div>
\t</nav>

\t<section class=\"container\">
        <div class=\"privileges-wrapper\">
            <a href=\"";
        // line 25
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("RemoveUser");
        echo "\" name=\"button\" type=\"submit\" class=\"privilege\">REMOVE USER</a>
            <a href=\"";
        // line 26
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("GrantUser");
        echo "\" name=\"button\" type=\"submit\" class=\"privilege\">GRANT USER</a>
            <a href=\"";
        // line 27
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("CleanCollection");
        echo "\" name=\"button\" type=\"submit\" class=\"privilege\">CLEAN COLLECTION</a>
            <a href=\"";
        // line 28
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AddBV");
        echo "\" name=\"button\" type=\"submit\" class=\"privilege\">ADD BV</a>
        </div>
\t</section>

    <footer>
\t\t<a href=\"";
        // line 33
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("LogOutPage");
        echo "\">Log out</a>
\t</footer>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "security/admin.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  126 => 33,  118 => 28,  114 => 27,  110 => 26,  106 => 25,  94 => 18,  88 => 17,  81 => 14,  75 => 12,  73 => 11,  69 => 9,  63 => 7,  61 => 6,  56 => 4,  53 => 3,  44 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}
\t<nav class=\"navbar home\">
\t\t<a class=\"logo\" href=\"{{ path('LogInHomePage') }}\"><img src=\"assets/logo.png\"></a>
\t\t<!--Check access to Back-Office-->
\t\t{% if user.getIsAdmin() == true %}
\t\t\t<a class=\"main-link\" href=\"{{ path('AdminPage') }}\">BACK-OFFICE</a>
\t\t{% endif %}

\t\t<!--Check number of Ballots in order to summon-->
\t\t{% if user.getBallotsNumber() >= 200 %}
\t\t\t<a class=\"main-link\" href=\"{{ path('SummonPage') }}\">SUMMON</a>
\t\t{% endif %}
        <a class=\"main-link\" href=\"{{ path('CollectionPage') }}\">COLLECTION</a>
        <div class=\"profil\">
            <p>
                <strong>{{ user.getSurname() }} {{ user.getFirstname() }}</strong><br>
                {{ user.getRank() }} | {{ user.getBallotsNumber() }} BV
            </p>
        </div>
\t</nav>

\t<section class=\"container\">
        <div class=\"privileges-wrapper\">
            <a href=\"{{ path('RemoveUser') }}\" name=\"button\" type=\"submit\" class=\"privilege\">REMOVE USER</a>
            <a href=\"{{ path('GrantUser') }}\" name=\"button\" type=\"submit\" class=\"privilege\">GRANT USER</a>
            <a href=\"{{ path('CleanCollection') }}\" name=\"button\" type=\"submit\" class=\"privilege\">CLEAN COLLECTION</a>
            <a href=\"{{ path('AddBV') }}\" name=\"button\" type=\"submit\" class=\"privilege\">ADD BV</a>
        </div>
\t</section>

    <footer>
\t\t<a href=\"{{ path('LogOutPage') }}\">Log out</a>
\t</footer>
{% endblock %}", "security/admin.html.twig", "C:\\Users\\samy\\Desktop\\matignon-the-gathering-master\\templates\\security\\admin.html.twig");
    }
}
