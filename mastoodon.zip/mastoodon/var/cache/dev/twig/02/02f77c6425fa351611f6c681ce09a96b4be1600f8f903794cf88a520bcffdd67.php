<?php

/* security/log_in.html.twig */
class __TwigTemplate_44e2f2b35ce7931d52d6007286892559a2006b40e43f3da421bd8908a277fadd extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "security/log_in.html.twig", 1);
        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "security/log_in.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "security/log_in.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_body($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "

\t<div class=\"container-alt\">
<div class=\"logo-container\">
<h1>
<a href=\"https://fosstodon.org/\"><img alt=\"Mastodon\" src=\"assets/logo.png\">
</a></h1>
</div>
<div class=\"form-container\">

<form class=\"simple_form new_user\" id=\"new_user\" novalidate=\"novalidate\" action=\"";
        // line 13
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("LogInPage");
        echo "\" accept-charset=\"UTF-8\" method=\"post\">
<input name=\"utf8\" type=\"hidden\" value=\"✓\"><input type=\"hidden\" name=\"authenticity_token\" value=\"7RzpRPnKNF7tZcJhd+Osvz72x1hUsOFvVJC1eYWPXUf1uO5sDHBeEr9gwjt7BsUdIq7zWdE5JloxhlGZ+dL3GA==\"><div class=\"fields-group\">
<div class=\"input with_label email optional user_email\"><div class=\"label_input\"><label class=\"email optional\" for=\"user_email\">E-mail address</label><div class=\"label_input__wrapper\">
<input aria-label=\"E-mail address\" class=\"string email optional\" autofocus=\"autofocus\" type=\"text\" value=\"\" name=\"_username\" id=\"user_email\"></div></div></div>
</div>
<div class=\"fields-group\">
<div class=\"input with_label password optional user_password\"><div class=\"label_input\"><label class=\"password optional\" for=\"user_password\">Password</label><div class=\"label_input__wrapper\">
<input aria-label=\"Password\" autocomplete=\"off\" class=\"password optional\" type=\"password\" name=\"_password\" id=\"user_password\"></div></div></div>
</div>
<div class=\"actions\">
<button name=\"button\" type=\"submit\" class=\"btn\">Log in</button>
</div>
</form><div class=\"form-footer\"><ul class=\"no-list\">
<li><a href=\"";
        // line 26
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("SignUpPage");
        echo "\">Sign up</a></li>
</ul>
</div>

</div>
</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "security/log_in.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  81 => 26,  65 => 13,  53 => 3,  44 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}


\t<div class=\"container-alt\">
<div class=\"logo-container\">
<h1>
<a href=\"https://fosstodon.org/\"><img alt=\"Mastodon\" src=\"assets/logo.png\">
</a></h1>
</div>
<div class=\"form-container\">

<form class=\"simple_form new_user\" id=\"new_user\" novalidate=\"novalidate\" action=\"{{ path('LogInPage') }}\" accept-charset=\"UTF-8\" method=\"post\">
<input name=\"utf8\" type=\"hidden\" value=\"✓\"><input type=\"hidden\" name=\"authenticity_token\" value=\"7RzpRPnKNF7tZcJhd+Osvz72x1hUsOFvVJC1eYWPXUf1uO5sDHBeEr9gwjt7BsUdIq7zWdE5JloxhlGZ+dL3GA==\"><div class=\"fields-group\">
<div class=\"input with_label email optional user_email\"><div class=\"label_input\"><label class=\"email optional\" for=\"user_email\">E-mail address</label><div class=\"label_input__wrapper\">
<input aria-label=\"E-mail address\" class=\"string email optional\" autofocus=\"autofocus\" type=\"text\" value=\"\" name=\"_username\" id=\"user_email\"></div></div></div>
</div>
<div class=\"fields-group\">
<div class=\"input with_label password optional user_password\"><div class=\"label_input\"><label class=\"password optional\" for=\"user_password\">Password</label><div class=\"label_input__wrapper\">
<input aria-label=\"Password\" autocomplete=\"off\" class=\"password optional\" type=\"password\" name=\"_password\" id=\"user_password\"></div></div></div>
</div>
<div class=\"actions\">
<button name=\"button\" type=\"submit\" class=\"btn\">Log in</button>
</div>
</form><div class=\"form-footer\"><ul class=\"no-list\">
<li><a href=\"{{ path('SignUpPage') }}\">Sign up</a></li>
</ul>
</div>

</div>
</div>
{% endblock %}
", "security/log_in.html.twig", "C:\\Users\\samy\\Desktop\\matignon-the-gathering-master\\templates\\security\\log_in.html.twig");
    }
}
