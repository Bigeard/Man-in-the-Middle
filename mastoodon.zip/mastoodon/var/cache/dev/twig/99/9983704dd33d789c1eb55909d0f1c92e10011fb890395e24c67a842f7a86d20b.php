<?php

/* main/log_out_home.html.twig */
class __TwigTemplate_29449166d834e033b5f20beddc1ab29a69f8d06f6e8973e9e85296af84a36e6f extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "main/log_out_home.html.twig", 1);
        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "main/log_out_home.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "main/log_out_home.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
<nav class=\"navbar\">
    <a class=\"logo\" href=\"";
        // line 6
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("LogOutHomePage");
        echo "\"><img src=\"assets/logo.png\"></a>
    <a class=\"main-link\" href=\"";
        // line 7
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("SignUpPage");
        echo "\">SIGN UP</a>
    <a class=\"sub-link\" href=\"";
        // line 8
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("LogInPage");
        echo "\">LOG IN</a>
</nav>

<section class=\"container\">
\t<div class=\"title\">
\t\t<img src=\"assets/banner.png\" draggable=\"false\">
\t\t<p>
\t\t\tEnter the magic world of french politics !
\t\t</p>

\t\t<table class=\"ranking\">
\t\t<tr>
\t\t\t<th>Firstname</th>
\t\t\t<th>Surname</th>
\t\t\t<th>Power</th>
\t\t</tr>
\t\t";
        // line 24
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["users"]) || array_key_exists("users", $context) ? $context["users"] : (function () { throw new Twig_Error_Runtime('Variable "users" does not exist.', 24, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["user"]) {
            // line 25
            echo "\t\t<tr>
\t\t\t<td>";
            // line 26
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "getFirstname", [], "method"), "html", null, true);
            echo "</td>
\t\t\t<td>";
            // line 27
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "getSurname", [], "method"), "html", null, true);
            echo "</td>
\t\t\t<td>";
            // line 28
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "getPower", [], "method"), "html", null, true);
            echo "</td>
\t\t</tr>
\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['user'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 31
        echo "\t</table> 
\t</div>

\t
</section>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "main/log_out_home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  108 => 31,  99 => 28,  95 => 27,  91 => 26,  88 => 25,  84 => 24,  65 => 8,  61 => 7,  57 => 6,  53 => 4,  44 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}

<nav class=\"navbar\">
    <a class=\"logo\" href=\"{{ path('LogOutHomePage') }}\"><img src=\"assets/logo.png\"></a>
    <a class=\"main-link\" href=\"{{ path('SignUpPage') }}\">SIGN UP</a>
    <a class=\"sub-link\" href=\"{{ path('LogInPage') }}\">LOG IN</a>
</nav>

<section class=\"container\">
\t<div class=\"title\">
\t\t<img src=\"assets/banner.png\" draggable=\"false\">
\t\t<p>
\t\t\tEnter the magic world of french politics !
\t\t</p>

\t\t<table class=\"ranking\">
\t\t<tr>
\t\t\t<th>Firstname</th>
\t\t\t<th>Surname</th>
\t\t\t<th>Power</th>
\t\t</tr>
\t\t{% for user in users %}
\t\t<tr>
\t\t\t<td>{{ user.getFirstname() }}</td>
\t\t\t<td>{{ user.getSurname() }}</td>
\t\t\t<td>{{ user.getPower() }}</td>
\t\t</tr>
\t\t{% endfor %}
\t</table> 
\t</div>

\t
</section>
{% endblock %}", "main/log_out_home.html.twig", "C:\\Users\\samy\\Desktop\\matignon-the-gathering-master\\templates\\main\\log_out_home.html.twig");
    }
}
