<?php

/* main/summon.html.twig */
class __TwigTemplate_19ec3db2d8dc9180e1825df76d48ba546f6a943d9973ac5408bb333e2944a02f extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "main/summon.html.twig", 1);
        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "main/summon.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "main/summon.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
\t<nav class=\"navbar home\">
\t\t<a class=\"logo\" href=\"";
        // line 6
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("LogInHomePage");
        echo "\"><img src=\"assets/logo.png\"></a>
\t\t<!--Check access to Back-Office-->
\t\t";
        // line 8
        if ((twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new Twig_Error_Runtime('Variable "user" does not exist.', 8, $this->source); })()), "getIsAdmin", [], "method") == true)) {
            // line 9
            echo "\t\t\t<a class=\"main-link\" href=\"";
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AdminPage");
            echo "\">BACK-OFFICE</a>
\t\t";
        }
        // line 11
        echo "
\t\t<!--Check number of Ballots in order to summon-->
\t\t";
        // line 13
        if ((twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new Twig_Error_Runtime('Variable "user" does not exist.', 13, $this->source); })()), "getBallotsNumber", [], "method") >= 200)) {
            // line 14
            echo "\t\t\t<a class=\"main-link\" href=\"";
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("SummonPage");
            echo "\">SUMMON</a>
\t\t";
        }
        // line 16
        echo "        <a class=\"main-link\" href=\"";
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("CollectionPage");
        echo "\">COLLECTION</a>
        <div class=\"profil\">
            <p>
                <strong>";
        // line 19
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new Twig_Error_Runtime('Variable "user" does not exist.', 19, $this->source); })()), "getSurname", [], "method"), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new Twig_Error_Runtime('Variable "user" does not exist.', 19, $this->source); })()), "getFirstname", [], "method"), "html", null, true);
        echo "</strong><br>
                ";
        // line 20
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new Twig_Error_Runtime('Variable "user" does not exist.', 20, $this->source); })()), "getRank", [], "method"), "html", null, true);
        echo " | ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new Twig_Error_Runtime('Variable "user" does not exist.', 20, $this->source); })()), "getBallotsNumber", [], "method"), "html", null, true);
        echo " BV
            </p>
        </div>
\t</nav>

\t<section class=\"container\">
\t\t<div class=\"container-summon\">
\t\t\t<h1>Congratulations, you got ";
        // line 27
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["card"]) || array_key_exists("card", $context) ? $context["card"] : (function () { throw new Twig_Error_Runtime('Variable "card" does not exist.', 27, $this->source); })()), "getName", [], "method"), "html", null, true);
        echo " !</h1>
\t\t\t<div class=\"summon\"style=\"background-image: url(assets/img/";
        // line 28
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["card"]) || array_key_exists("card", $context) ? $context["card"] : (function () { throw new Twig_Error_Runtime('Variable "card" does not exist.', 28, $this->source); })()), "getImage", [], "method"), "html", null, true);
        echo ")\">
\t\t\t\t<span class=\"card-name-summon\">";
        // line 29
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["card"]) || array_key_exists("card", $context) ? $context["card"] : (function () { throw new Twig_Error_Runtime('Variable "card" does not exist.', 29, $this->source); })()), "getName", [], "method"), "html", null, true);
        echo "</span>
\t\t\t\t";
        // line 30
        if ((twig_get_attribute($this->env, $this->source, (isset($context["card"]) || array_key_exists("card", $context) ? $context["card"] : (function () { throw new Twig_Error_Runtime('Variable "card" does not exist.', 30, $this->source); })()), "getRarity", [], "method") == 1)) {
            // line 31
            echo "\t\t\t\t\t<img src=\"assets/bronze_card.png\">
\t\t\t\t";
        } elseif ((twig_get_attribute($this->env, $this->source,         // line 32
(isset($context["card"]) || array_key_exists("card", $context) ? $context["card"] : (function () { throw new Twig_Error_Runtime('Variable "card" does not exist.', 32, $this->source); })()), "getRarity", [], "method") == 2)) {
            // line 33
            echo "\t\t\t\t\t<img src=\"assets/silver_card.png\">
\t\t\t\t";
        } elseif ((twig_get_attribute($this->env, $this->source,         // line 34
(isset($context["card"]) || array_key_exists("card", $context) ? $context["card"] : (function () { throw new Twig_Error_Runtime('Variable "card" does not exist.', 34, $this->source); })()), "getRarity", [], "method") == 3)) {
            // line 35
            echo "\t\t\t\t\t<img src=\"assets/gold_card.png\">
\t\t\t\t";
        } else {
            // line 37
            echo "\t\t\t\t\t<img src=\"assets/bronze_card.png\">
\t\t\t\t";
        }
        // line 39
        echo "\t\t\t\t
\t\t\t</div>
\t\t\t<div class=\"home-buttons\">
\t\t\t\t<a href=\"";
        // line 42
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("CollectionPage");
        echo "\">BACK TO COLLECTION</a>
\t\t\t</div>
\t\t</div>
\t</section>
\t
\t<footer>
\t\t<a href=\"";
        // line 48
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("LogOutPage");
        echo "\">Log out</a>
\t</footer>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "main/summon.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  153 => 48,  144 => 42,  139 => 39,  135 => 37,  131 => 35,  129 => 34,  126 => 33,  124 => 32,  121 => 31,  119 => 30,  115 => 29,  111 => 28,  107 => 27,  95 => 20,  89 => 19,  82 => 16,  76 => 14,  74 => 13,  70 => 11,  64 => 9,  62 => 8,  57 => 6,  53 => 4,  44 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}

\t<nav class=\"navbar home\">
\t\t<a class=\"logo\" href=\"{{ path('LogInHomePage') }}\"><img src=\"assets/logo.png\"></a>
\t\t<!--Check access to Back-Office-->
\t\t{% if user.getIsAdmin() == true %}
\t\t\t<a class=\"main-link\" href=\"{{ path('AdminPage') }}\">BACK-OFFICE</a>
\t\t{% endif %}

\t\t<!--Check number of Ballots in order to summon-->
\t\t{% if user.getBallotsNumber() >= 200 %}
\t\t\t<a class=\"main-link\" href=\"{{ path('SummonPage') }}\">SUMMON</a>
\t\t{% endif %}
        <a class=\"main-link\" href=\"{{ path('CollectionPage') }}\">COLLECTION</a>
        <div class=\"profil\">
            <p>
                <strong>{{ user.getSurname() }} {{ user.getFirstname() }}</strong><br>
                {{ user.getRank() }} | {{ user.getBallotsNumber() }} BV
            </p>
        </div>
\t</nav>

\t<section class=\"container\">
\t\t<div class=\"container-summon\">
\t\t\t<h1>Congratulations, you got {{ card.getName() }} !</h1>
\t\t\t<div class=\"summon\"style=\"background-image: url(assets/img/{{ card.getImage() }})\">
\t\t\t\t<span class=\"card-name-summon\">{{ card.getName() }}</span>
\t\t\t\t{% if card.getRarity() == 1 %}
\t\t\t\t\t<img src=\"assets/bronze_card.png\">
\t\t\t\t{% elseif card.getRarity() == 2 %}
\t\t\t\t\t<img src=\"assets/silver_card.png\">
\t\t\t\t{% elseif card.getRarity() == 3 %}
\t\t\t\t\t<img src=\"assets/gold_card.png\">
\t\t\t\t{% else %}
\t\t\t\t\t<img src=\"assets/bronze_card.png\">
\t\t\t\t{% endif %}
\t\t\t\t
\t\t\t</div>
\t\t\t<div class=\"home-buttons\">
\t\t\t\t<a href=\"{{ path('CollectionPage') }}\">BACK TO COLLECTION</a>
\t\t\t</div>
\t\t</div>
\t</section>
\t
\t<footer>
\t\t<a href=\"{{ path('LogOutPage') }}\">Log out</a>
\t</footer>
{% endblock %}", "main/summon.html.twig", "C:\\Users\\samy\\Desktop\\matignon-the-gathering-master\\templates\\main\\summon.html.twig");
    }
}
