<?php

use Symfony\Component\Routing\Matcher\Dumper\PhpMatcherTrait;
use Symfony\Component\Routing\RequestContext;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class srcApp_KernelDevDebugContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    use PhpMatcherTrait;

    public function __construct(RequestContext $context)
    {
        $this->context = $context;
        $this->staticRoutes = array(
            '/' => array(array(array('_route' => 'LogOutHomePage', '_controller' => 'App\\Controller\\MainController::getLogOutHomePageView'), null, null, null, false, false, null)),
            '/home' => array(array(array('_route' => 'LogInHomePage', '_controller' => 'App\\Controller\\MainController::getLogInHomePageView'), null, null, null, false, false, null)),
            '/summon' => array(array(array('_route' => 'SummonPage', '_controller' => 'App\\Controller\\MainController::getSummonPageView'), null, null, null, false, false, null)),
            '/collection' => array(array(array('_route' => 'CollectionPage', '_controller' => 'App\\Controller\\MainController::getCollectionPageView'), null, null, null, false, false, null)),
            '/claimbv' => array(array(array('_route' => 'ClaimBV', '_controller' => 'App\\Controller\\MainController::claimBV'), null, null, null, false, false, null)),
            '/signup' => array(array(array('_route' => 'SignUpPage', '_controller' => 'App\\Controller\\SecurityController::getSignUpPageView'), null, null, null, false, false, null)),
            '/login' => array(array(array('_route' => 'LogInPage', '_controller' => 'App\\Controller\\SecurityController::getLogInPageView'), null, null, null, false, false, null)),
            '/logout' => array(array(array('_route' => 'LogOutPage', '_controller' => 'App\\Controller\\SecurityController::logout'), null, null, null, false, false, null)),
            '/admin' => array(array(array('_route' => 'AdminPage', '_controller' => 'App\\Controller\\SecurityController::getAdminView'), null, null, null, false, false, null)),
            '/admin/remove_user' => array(array(array('_route' => 'RemoveUser', '_controller' => 'App\\Controller\\SecurityController::getAdminRemoveUserView'), null, null, null, false, false, null)),
            '/admin/remove_user_method' => array(array(array('_route' => 'RemoveUserMethod', '_controller' => 'App\\Controller\\SecurityController::removeUser'), null, null, null, false, false, null)),
            '/admin/grant_user' => array(array(array('_route' => 'GrantUser', '_controller' => 'App\\Controller\\SecurityController::getAdminGrantUserView'), null, null, null, false, false, null)),
            '/admin/grant_user_method' => array(array(array('_route' => 'GrantUserMethod', '_controller' => 'App\\Controller\\SecurityController::grantUser'), null, null, null, false, false, null)),
            '/admin/clean_collection' => array(array(array('_route' => 'CleanCollection', '_controller' => 'App\\Controller\\SecurityController::getAdminCleanCollectionView'), null, null, null, false, false, null)),
            '/admin/clean_collection_method' => array(array(array('_route' => 'CleanCollectionMethod', '_controller' => 'App\\Controller\\SecurityController::cleanCollection'), null, null, null, false, false, null)),
            '/admin/add_bv' => array(array(array('_route' => 'AddBV', '_controller' => 'App\\Controller\\SecurityController::getAdminAddBVView'), null, null, null, false, false, null)),
            '/admin/add_bv_method' => array(array(array('_route' => 'AddBVMethod', '_controller' => 'App\\Controller\\SecurityController::addBV'), null, null, null, false, false, null)),
            '/_profiler' => array(array(array('_route' => '_profiler_home', '_controller' => 'web_profiler.controller.profiler::homeAction'), null, null, null, true, false, null)),
            '/_profiler/search' => array(array(array('_route' => '_profiler_search', '_controller' => 'web_profiler.controller.profiler::searchAction'), null, null, null, false, false, null)),
            '/_profiler/search_bar' => array(array(array('_route' => '_profiler_search_bar', '_controller' => 'web_profiler.controller.profiler::searchBarAction'), null, null, null, false, false, null)),
            '/_profiler/phpinfo' => array(array(array('_route' => '_profiler_phpinfo', '_controller' => 'web_profiler.controller.profiler::phpinfoAction'), null, null, null, false, false, null)),
            '/_profiler/open' => array(array(array('_route' => '_profiler_open_file', '_controller' => 'web_profiler.controller.profiler::openAction'), null, null, null, false, false, null)),
        );
        $this->regexpList = array(
            0 => '{^(?'
                    .'|/_(?'
                        .'|error/(\\d+)(?:\\.([^/]++))?(*:38)'
                        .'|wdt/([^/]++)(*:57)'
                        .'|profiler/([^/]++)(?'
                            .'|/(?'
                                .'|search/results(*:102)'
                                .'|router(*:116)'
                                .'|exception(?'
                                    .'|(*:136)'
                                    .'|\\.css(*:149)'
                                .')'
                            .')'
                            .'|(*:159)'
                        .')'
                    .')'
                .')/?$}sDu',
        );
        $this->dynamicRoutes = array(
            38 => array(array(array('_route' => '_twig_error_test', '_controller' => 'twig.controller.preview_error::previewErrorPageAction', '_format' => 'html'), array('code', '_format'), null, null, false, true, null)),
            57 => array(array(array('_route' => '_wdt', '_controller' => 'web_profiler.controller.profiler::toolbarAction'), array('token'), null, null, false, true, null)),
            102 => array(array(array('_route' => '_profiler_search_results', '_controller' => 'web_profiler.controller.profiler::searchResultsAction'), array('token'), null, null, false, false, null)),
            116 => array(array(array('_route' => '_profiler_router', '_controller' => 'web_profiler.controller.router::panelAction'), array('token'), null, null, false, false, null)),
            136 => array(array(array('_route' => '_profiler_exception', '_controller' => 'web_profiler.controller.exception::showAction'), array('token'), null, null, false, false, null)),
            149 => array(array(array('_route' => '_profiler_exception_css', '_controller' => 'web_profiler.controller.exception::cssAction'), array('token'), null, null, false, false, null)),
            159 => array(array(array('_route' => '_profiler', '_controller' => 'web_profiler.controller.profiler::panelAction'), array('token'), null, null, false, true, null)),
        );
    }
}
